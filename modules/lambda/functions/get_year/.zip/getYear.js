const zodiacCombination = require('./getZodiacCombination');

exports.handler = function (event, context, callback) {
    var date = event.params.querystring.date
    var info = new zodiacCombination(`${date}`, "0")
    // var duo = user.getInfo().duo

    var response = {
      statusCode: 200,
      headers: {
        'Content-Type': 'application/json',
      },
      body: info
    }
    callback(null, response)
  }